import json
import os
import re
from typing import Any

from langflow.custom import Component
from langflow.io import MessageTextInput, Output, StrInput, DropdownInput
from langflow.schema import Data
from langchain_core.tools import StructuredTool


class CourseReviewSearch(Component):
    display_name = "Course Review Search"
    description = "Searches MS-HCI student course reviews and returns sentiment-enriched results. Can be used as an agent tool."
    icon = "star"
    name = "CourseReviewSearch"

    inputs = [
        MessageTextInput(
            name="query",
            display_name="Query",
            info="Student question or course they are asking about.",
            required=True,
            tool_mode=True,
        ),
        StrInput(
            name="json_path",
            display_name="JSON Path",
            info="Absolute path to the course reviews JSON file.",
            value="/path/to/mshci_course_feedback_rag.json",
            required=True,
        ),
        StrInput(
            name="course_id_filter",
            display_name="Course ID Filter",
            info="Optional: filter by course ID e.g. CS 6470 or MUSI 6002.",
            required=False,
            tool_mode=True,
        ),
        DropdownInput(
            name="sentiment_filter",
            display_name="Sentiment Filter",
            info="Optional: filter reviews by sentiment.",
            options=["Any", "positive", "mixed", "negative", "neutral"],
            value="Any",
            required=False,
            tool_mode=True,
        ),
        DropdownInput(
            name="workload_filter",
            display_name="Workload Filter",
            info="Optional: filter by whether reviews flag heavy workload.",
            options=["Any", "heavy_only", "light_only"],
            value="Any",
            required=False,
            tool_mode=True,
        ),
        StrInput(
            name="instructor_filter",
            display_name="Instructor Filter",
            info="Optional: filter by instructor name (partial match).",
            required=False,
            tool_mode=True,
        ),
        StrInput(
            name="semester_filter",
            display_name="Semester Filter",
            info="Optional: filter by semester e.g. Fall or Spring.",
            required=False,
            tool_mode=True,
        ),
    ]

    outputs = [
        Output(display_name="Review Results", name="results", method="search_reviews"),
        Output(
            display_name="Tool",
            name="tool",
            method="build_tool",
        ),
    ]

    def _load_reviews(self) -> list[dict[str, Any]]:
        json_path = self.json_path

        if not os.path.exists(json_path):
            raise FileNotFoundError(f"JSON file not found: {json_path}")

        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if isinstance(data, list):
            return data

        raise ValueError("Unsupported format. Expected a list of review objects.")

    def _matches_filters(self, review: dict[str, Any]) -> bool:
        # Course ID filter (partial match, case-insensitive)
        if self.course_id_filter:
            course_id = str(review.get("course_id", "")).upper()
            if self.course_id_filter.upper() not in course_id:
                return False

        # Sentiment filter
        if self.sentiment_filter and self.sentiment_filter != "Any":
            if review.get("sentiment", "") != self.sentiment_filter:
                return False

        # Workload filter
        if self.workload_filter and self.workload_filter != "Any":
            heavy = review.get("heavy_workload_flag", False)
            if self.workload_filter == "heavy_only" and not heavy:
                return False
            if self.workload_filter == "light_only" and heavy:
                return False

        # Instructor filter (partial match, case-insensitive)
        if self.instructor_filter:
            instructor = str(review.get("instructor", "")).lower()
            if self.instructor_filter.lower() not in instructor:
                return False

        # Semester filter
        if self.semester_filter:
            semester = str(review.get("semester", "")).lower()
            if self.semester_filter.lower() not in semester:
                return False

        return True

    def _score_review(self, review: dict[str, Any], query: str) -> int:
        q = query.lower().strip()
        q_clean = re.sub(r"[^a-z0-9\s]", "", q)

        course_id = str(review.get("course_id", "")).lower()
        course_name = str(review.get("course_name", "")).lower()
        student_review = str(review.get("student_review", "")).lower()
        course_description = str(review.get("course_description", "")).lower()
        instructor = str(review.get("instructor", "")).lower()

        score = 0

        # Strong boost for exact course ID match
        if course_id in q_clean:
            score += 50

        # Course name match
        if q_clean in course_name:
            score += 20

        # Instructor name match
        if q_clean in instructor:
            score += 15

        # Keyword matches across fields
        query_terms = [t for t in q_clean.split() if len(t) > 2]
        for term in query_terms:
            if term in course_id:
                score += 10
            if term in course_name:
                score += 8
            if term in course_description:
                score += 4
            if term in student_review:
                score += 3

        # Boost positive sentiment reviews slightly for general queries
        if review.get("sentiment") == "positive":
            score += 2
        elif review.get("sentiment") == "negative":
            score -= 2

        return score

    def _summarize_sentiment(self, reviews: list[dict[str, Any]]) -> dict[str, Any]:
        """Aggregate sentiment stats across the returned reviews."""
        total = len(reviews)
        if total == 0:
            return {}

        sentiments = [r.get("sentiment", "neutral") for r in reviews]
        heavy_workload_count = sum(1 for r in reviews if r.get("heavy_workload_flag", False))

        sentiment_counts = {
            "positive": sentiments.count("positive"),
            "mixed": sentiments.count("mixed"),
            "negative": sentiments.count("negative"),
            "neutral": sentiments.count("neutral"),
        }

        dominant = max(sentiment_counts, key=sentiment_counts.get)

        return {
            "total_reviews": total,
            "dominant_sentiment": dominant,
            "sentiment_breakdown": sentiment_counts,
            "heavy_workload_flagged": heavy_workload_count,
            "heavy_workload_percentage": round((heavy_workload_count / total) * 100),
        }

    def build_tool(self) -> StructuredTool:
        """Expose this component as a LangChain tool for use with agents."""
        return StructuredTool.from_function(
            name="course_review_search",
            description=(
                "Search MS-HCI student course reviews. "
                "Use this to find what students said about a course, "
                "get sentiment summaries, check workload levels, or "
                "find reviews by instructor or semester. "
                "Input should be a natural language query or course ID like 'CS 6470'."
            ),
            func=self._run_as_tool,
        )

    def _run_as_tool(self, query: str) -> str:
        """Wrapper so the tool returns a string the agent can read directly."""
        self.query = query
        result = self.search_reviews()
        data = result.data

        if data.get("count", 0) == 0:
            return data.get("message", "No reviews found.")

        summary = data.get("sentiment_summary", {})
        lines = [
            f"Found {data['count']} review(s) for query: '{query}'",
            f"Dominant sentiment: {summary.get('dominant_sentiment', 'N/A')}",
            f"Sentiment breakdown: {summary.get('sentiment_breakdown', {})}",
            f"Heavy workload flagged in {summary.get('heavy_workload_percentage', 0)}% of reviews",
            "",
            "--- Reviews ---",
        ]

        for r in data.get("results", []):
            lines.append(
                f"\n[{r['course_id']} - {r['course_name']}] "
                f"Instructor: {r['instructor']} | "
                f"{r['semester']} {r['year']} | "
                f"Sentiment: {r['sentiment']} | "
                f"Heavy workload: {r['heavy_workload_flag']}\n"
                f"Review: {r['student_review']}"
            )

        return "\n".join(lines)

    def search_reviews(self) -> Data:
        reviews = self._load_reviews()
        query = str(self.query)

        # Check if query contains an explicit course code e.g. "CS 6470"
        course_code_match = re.search(r"\b([A-Z]{2,5}\s?\d{4}[A-Z]?)\b", query.upper())

        if course_code_match:
            requested_code = course_code_match.group(1).replace("  ", " ").strip()
            filtered = [
                r for r in reviews
                if str(r.get("course_id", "")).upper() == requested_code
                and self._matches_filters(r)
            ]
        else:
            filtered = [r for r in reviews if self._matches_filters(r)]
            scored = []
            for review in filtered:
                score = self._score_review(review, query)
                if score > 0:
                    scored.append((score, review))
            scored.sort(key=lambda x: x[0], reverse=True)
            filtered = [r for _, r in scored[:10]]

        if not filtered:
            return Data(
                data={
                    "query": query,
                    "count": 0,
                    "results": [],
                    "sentiment_summary": {},
                    "message": "No matching reviews found. Try adjusting your filters or query.",
                }
            )

        # Build simplified output for each review
        simplified = []
        for r in filtered:
            simplified.append(
                {
                    "course_id": r.get("course_id", ""),
                    "course_name": r.get("course_name", ""),
                    "instructor": r.get("instructor", ""),
                    "semester": r.get("semester", ""),
                    "year": r.get("year", ""),
                    "sentiment": r.get("sentiment", ""),
                    "heavy_workload_flag": r.get("heavy_workload_flag", False),
                    "course_description": r.get("course_description", ""),
                    "student_review": r.get("student_review", ""),
                }
            )

        sentiment_summary = self._summarize_sentiment(filtered)

        return Data(
            data={
                "query": query,
                "count": len(simplified),
                "sentiment_summary": sentiment_summary,
                "results": simplified,
            }
        )
