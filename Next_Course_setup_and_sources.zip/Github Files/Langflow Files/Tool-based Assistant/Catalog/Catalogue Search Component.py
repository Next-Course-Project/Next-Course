import json
from pathlib import Path
from typing import List, Dict, Any, Optional

from langflow.custom import Component
from langflow.io import MessageTextInput, IntInput, StrInput, Output
from langflow.schema import Message


class CourseLookupComponent(Component):
    display_name = "Course Lookup"
    description = "Look up Georgia Tech course data from a normalized JSON file using a natural language query."
    icon = "search"
    name = "course_lookup"

    inputs = [
        MessageTextInput(
            name="query",
            display_name="Query",
            info="Natural language query such as 'What time is CS 6601?' or 'Find 3 credit AE classes on Tuesday'.",
            tool_mode=True,
        ),
        StrInput(
            name="data_file",
            display_name="Data File Path",
            value="/Users/paul/Documents/ThesisProject/crawler-v2/data/latest_courses.json",
            info="Absolute path to latest_courses.json",
        ),
        IntInput(
            name="limit",
            display_name="Limit",
            value=10,
            info="Maximum number of results to return",
        ),
    ]

    outputs = [
        Output(
            name="tool_output",
            display_name="Tool Output",
            method="run_lookup",
        )
    ]

    def _load_courses(self) -> List[Dict[str, Any]]:
        path = Path(self.data_file)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            raise ValueError("Expected latest_courses.json to contain a list of course rows.")

        return data

    def _time_to_minutes(self, t: str) -> Optional[int]:
        if not t or not isinstance(t, str):
            return None
        try:
            h, m = t.split(":")
            return int(h) * 60 + int(m)
        except Exception:
            return None

    def _infer_filters_from_query(self, query: str) -> Dict[str, Any]:
        q = (query or "").strip()
        words = q.replace(",", " ").replace("?", " ").split()

        subject = ""
        course_number = ""
        day = ""
        instructor = ""
        keyword = ""

        min_credits = None
        max_credits = None
        start_after = None
        end_before = None

        day_map = {
            "monday": "M",
            "tuesday": "T",
            "wednesday": "W",
            "thursday": "R",
            "friday": "F",
            "mw": "MW",
            "wf": "WF",
            "tr": "TR",
            "m": "M",
            "t": "T",
            "w": "W",
            "r": "R",
            "f": "F",
        }

        for i, word in enumerate(words):
            lower = word.lower()
            upper = word.upper()

            if upper.isalpha() and 2 <= len(upper) <= 4 and i + 1 < len(words) and words[i + 1].isdigit():
                subject = upper
                course_number = words[i + 1]

            if lower in day_map:
                day = day_map[lower]

            if lower.isdigit():
                n = int(lower)
                if i + 1 < len(words) and "credit" in words[i + 1].lower():
                    min_credits = n
                    max_credits = n

        q_lower = q.lower()

        if "after " in q_lower:
            after_part = q_lower.split("after ", 1)[1].split()[0]
            start_after = self._normalize_time_token(after_part)

        if "before " in q_lower:
            before_part = q_lower.split("before ", 1)[1].split()[0]
            end_before = self._normalize_time_token(before_part)

        keyword = q

        return {
            "subject": subject,
            "course_number": course_number,
            "day": day,
            "instructor": instructor,
            "keyword": keyword,
            "min_credits": min_credits,
            "max_credits": max_credits,
            "start_after": start_after,
            "end_before": end_before,
        }

    def _normalize_time_token(self, token: str) -> Optional[str]:
        token = token.strip().lower().replace(".", "")
        if not token:
            return None

        if ":" in token:
            try:
                h, m = token.split(":")
                h = int(h)
                m = int(m)
                return f"{h:02d}:{m:02d}"
            except Exception:
                return None

        if token.isdigit():
            val = int(token)
            if 0 <= val <= 23:
                return f"{val:02d}:00"
            if len(token) == 4:
                return f"{token[:2]}:{token[2:]}"
        return None

    def run_lookup(self) -> Message:
        try:
            courses = self._load_courses()
            query = (self.query or "").strip()

            inferred = self._infer_filters_from_query(query)

            subject = inferred["subject"]
            course_number = inferred["course_number"]
            day = inferred["day"]
            keyword = inferred["keyword"].lower() if inferred["keyword"] else ""
            instructor = inferred["instructor"].lower() if inferred["instructor"] else ""

            min_credits = inferred["min_credits"]
            max_credits = inferred["max_credits"]
            start_after = inferred["start_after"]
            end_before = inferred["end_before"]

            start_after_mins = self._time_to_minutes(start_after) if start_after else None
            end_before_mins = self._time_to_minutes(end_before) if end_before else None

            results: List[Dict[str, Any]] = []

            for c in courses:
                c_subject = str(c.get("subject", "")).upper()
                c_course_number = str(c.get("course_number", "")).strip()
                c_days = str(c.get("days", "")).upper()
                c_title = str(c.get("title", ""))
                c_desc = str(c.get("description", ""))
                c_instr = str(c.get("instructor", "")).lower()
                c_credits = c.get("credits")
                c_start = self._time_to_minutes(str(c.get("start_time", "")))
                c_end = self._time_to_minutes(str(c.get("end_time", "")))

                if subject and c_subject != subject:
                    continue

                if course_number and c_course_number != course_number:
                    continue

                if day and day not in c_days:
                    continue

                if min_credits is not None and (c_credits is None or c_credits < min_credits):
                    continue

                if max_credits is not None and (c_credits is None or c_credits > max_credits):
                    continue

                if start_after_mins is not None and c_start is not None and c_start < start_after_mins:
                    continue

                if end_before_mins is not None and c_end is not None and c_end > end_before_mins:
                    continue

                if instructor and instructor not in c_instr:
                    continue

                structured_filter_used = any([
                    subject,
                    course_number,
                    day,
                    min_credits is not None,
                    max_credits is not None,
                    start_after_mins is not None,
                    end_before_mins is not None,
                    instructor,
                ])

                # Only use keyword search if no structured filters were detected
                if keyword and not structured_filter_used:
                    haystack = f"{c_subject} {c_course_number} {c_title} {c_desc} {c_instr}".lower()
                    keyword_parts = [part for part in query.lower().replace("?", " ").split() if part]
                    if not any(part in haystack for part in keyword_parts):
                        continue

                results.append(c)

                if len(results) >= max(1, int(self.limit or 10)):
                    break

            self.status = f"Found {len(results)} matching course rows."

            if not results:
                return Message(text="No matching courses found.")

            formatted: List[str] = []
            for c in results:
                formatted.append(
                    f"{c.get('subject', '')} {c.get('course_number', '')} — {c.get('title', '')}\n"
                    f"Section {c.get('section', '')} | CRN {c.get('crn', '')}\n"
                    f"{c.get('days', '')} {c.get('start_time', '')}-{c.get('end_time', '')}\n"
                    f"Instructor: {c.get('instructor', '')}\n"
                    f"Credits: {c.get('credits', '')} | Location: {c.get('location', '')}\n"
                    f"Description: {c.get('description', '')}\n"
                )

            return Message(text="\n".join(formatted))

        except Exception as e:
            self.status = f"Lookup failed: {e}"
            return Message(text=f"Lookup failed: {e}")