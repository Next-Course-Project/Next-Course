import json
import os
import re
from typing import Any

from langflow.custom import Component
from langflow.io import MessageTextInput, Output, StrInput, DropdownInput
from langflow.schema import Data
from langchain_core.tools import StructuredTool


class HandbookSearch(Component):
    display_name = "MS-HCI Handbook Search"
    description = (
        "Searches the MS-HCI Student Handbook for degree requirements, "
        "specialization tracks, elective courses, project requirements, "
        "academic calendar, FAQs, and contact information. "
        "Can be used as an agent tool."
    )
    icon = "book-open"
    name = "HandbookSearch"

    inputs = [
        MessageTextInput(
            name="query",
            display_name="Query",
            info="Student question about the MS-HCI program.",
            required=True,
            tool_mode=True,
        ),
        StrInput(
            name="json_path",
            display_name="JSON Path",
            info="Absolute path to the MS-HCI handbook JSON file.",
            value="/path/to/mshci_handbook.json",
            required=True,
        ),
        DropdownInput(
            name="section_filter",
            display_name="Section Filter",
            info="Optionally restrict search to a specific section of the handbook.",
            options=[
                "All",
                "Degree Requirements",
                "Fixed Core Courses",
                "Specializations",
                "Elective Courses",
                "Research Project",
                "Academic Calendar",
                "FAQs",
                "Contact",
                "Other Requirements",
            ],
            value="All",
            required=False,
            tool_mode=True,
        ),
        DropdownInput(
            name="specialization_filter",
            display_name="Specialization Filter",
            info="Optionally restrict results to a specific specialization track.",
            options=[
                "All",
                "Interactive Computing",
                "Digital Media",
                "Industrial Design",
                "Psychology",
            ],
            value="All",
            required=False,
            tool_mode=True,
        ),
    ]

    outputs = [
        Output(
            display_name="Handbook Results",
            name="results",
            method="search_handbook",
        ),
        Output(
            display_name="Tool",
            name="tool",
            method="build_tool",
        ),
    ]

    # ------------------------------------------------------------------ #
    # Loading
    # ------------------------------------------------------------------ #

    def _load_handbook(self) -> dict[str, Any]:
        path = self.json_path
        if not os.path.exists(path):
            raise FileNotFoundError(f"Handbook JSON not found: {path}")
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    # ------------------------------------------------------------------ #
    # Intent detection
    # ------------------------------------------------------------------ #

    def _detect_intent(self, query: str) -> str:
        """
        Classify the query into a handbook section so we know
        where to look first.
        """
        q = query.lower()

        faq_signals = [
            "how many", "what gpa", "minimum grade", "do i need",
            "when do i", "can i", "am i required", "is it required",
            "what is the", "how do i", "who do i contact",
        ]
        calendar_signals = [
            "deadline", "date", "when is", "schedule", "calendar",
            "registration", "orientation", "break", "holiday",
            "commencement", "graduation", "exam", "semester start",
            "first day", "last day",
        ]
        contact_signals = [
            "contact", "email", "who is", "director", "advisor name",
            "program manager", "staff", "faculty",
        ]
        project_signals = [
            "project", "6998", "proposal", "midpoint", "final report",
            "presentation", "irb", "advisor", "mentor", "deliverable",
            "thesis", "capstone",
        ]
        elective_signals = [
            "elective", "outside track", "non-cs", "non-lmc", "non-id",
            "non-psyc", "approved courses", "other courses", "mgt", "musi",
            "isye", "ae ", "pubp", "inta",
        ]
        specialization_signals = [
            "specialization", "track", "interactive computing", "digital media",
            "industrial design", "psychology", "software courses",
            "design evaluation", "cognitive modeling", "lmc", "id 6",
        ]
        core_signals = [
            "core", "6755", "6023", "6753", "foundations", "research methods",
            "professional preparation", "required courses", "first semester",
        ]
        requirement_signals = [
            "requirement", "credit hours", "total credits", "gpa", "grade",
            "internship", "gra", "gta", "how many credits",
        ]

        if any(s in q for s in faq_signals):
            return "faqs"
        if any(s in q for s in calendar_signals):
            return "academic_calendar"
        if any(s in q for s in contact_signals):
            return "contact"
        if any(s in q for s in project_signals):
            return "research_project"
        if any(s in q for s in elective_signals):
            return "elective_courses"
        if any(s in q for s in specialization_signals):
            return "specializations"
        if any(s in q for s in core_signals):
            return "fixed_core_courses"
        if any(s in q for s in requirement_signals):
            return "degree_requirements"
        return "all"

    # ------------------------------------------------------------------ #
    # Section-specific search methods
    # ------------------------------------------------------------------ #

    def _search_faqs(self, handbook: dict, query: str) -> list[dict]:
        q = query.lower()
        results = []
        for faq in handbook.get("faqs", []):
            score = 0
            question = faq.get("question", "").lower()
            answer = faq.get("answer", "").lower()
            for term in q.split():
                if len(term) < 3:
                    continue
                if term in question:
                    score += 5
                if term in answer:
                    score += 2
            if score > 0:
                results.append({"score": score, "section": "FAQ", "content": faq})
        return sorted(results, key=lambda x: x["score"], reverse=True)[:3]

    def _search_calendar(self, handbook: dict, query: str) -> list[dict]:
        q = query.lower()
        results = []
        calendar = handbook.get("academic_calendar", {})
        for semester, events in calendar.items():
            label = "Fall 2025" if "fall" in semester else "Spring 2026"
            for event in events:
                event_text = event.get("event", "").lower()
                dates = event.get("dates", "")
                score = 0
                for term in q.split():
                    if len(term) < 3:
                        continue
                    if term in event_text:
                        score += 5
                    if term in dates.lower():
                        score += 3
                if score > 0:
                    results.append({
                        "score": score,
                        "section": f"Academic Calendar - {label}",
                        "content": {"semester": label, "dates": dates, "event": event.get("event", "")},
                    })
        return sorted(results, key=lambda x: x["score"], reverse=True)[:5]

    def _search_contact(self, handbook: dict, query: str) -> list[dict]:
        q = query.lower()
        results = []
        contact = handbook.get("contact", {})

        for person in contact.get("staff", []):
            text = f"{person.get('name','')} {person.get('title','')} {person.get('email','')}".lower()
            if any(t in text for t in q.split() if len(t) > 2):
                results.append({"score": 5, "section": "Program Staff", "content": person})

        for person in contact.get("associate_directors", []):
            text = f"{person.get('name','')} {person.get('school','')} {person.get('email','')}".lower()
            if any(t in text for t in q.split() if len(t) > 2):
                results.append({"score": 4, "section": "Associate Directors", "content": person})

        # If no specific match, return all staff
        if not results:
            results = [
                {"score": 1, "section": "Program Staff", "content": p}
                for p in contact.get("staff", [])
            ] + [
                {"score": 1, "section": "Associate Directors", "content": p}
                for p in contact.get("associate_directors", [])
            ]
        return results

    def _search_requirements(self, handbook: dict, query: str) -> list[dict]:
        q = query.lower()
        results = []
        reqs = handbook.get("degree_requirements", {})

        results.append({
            "score": 5,
            "section": "Degree Requirements Overview",
            "content": {
                "overview": reqs.get("overview", ""),
                "gpa_and_grade_requirements": reqs.get("gpa_and_grade_requirements", {}),
                "registration_advice": reqs.get("registration_advice", ""),
                "credit_hours_by_specialization": reqs.get("credit_hours_by_specialization", []),
            },
        })
        other = handbook.get("other_requirements", {})
        if other:
            results.append({"score": 4, "section": "Other Requirements", "content": other})
        return results

    def _search_core_courses(self, handbook: dict, query: str) -> list[dict]:
        q = query.lower()
        core = handbook.get("fixed_core_courses", {})
        results = []
        for course in core.get("courses", []):
            score = 0
            text = f"{course.get('course_id','')} {course.get('title','')}".lower()
            for term in q.split():
                if len(term) > 2 and term in text:
                    score += 5
            results.append({
                "score": score if score > 0 else 1,
                "section": "Fixed Core Courses",
                "content": {
                    "course": course,
                    "minimum_grade": core.get("minimum_grade", "B"),
                    "notes": core.get("notes", ""),
                    "total_credit_hours": core.get("total_credit_hours", 9),
                },
            })
        return sorted(results, key=lambda x: x["score"], reverse=True)

    def _search_specializations(
        self, handbook: dict, query: str, specialization_filter: str
    ) -> list[dict]:
        q = query.lower()
        results = []
        specs = handbook.get("specializations", {})

        track_map = {
            "Interactive Computing": "interactive_computing",
            "Digital Media": "digital_media",
            "Industrial Design": "industrial_design",
            "Psychology": "psychology",
        }

        tracks_to_search = (
            {track_map[specialization_filter]: specs.get(track_map[specialization_filter], {})}
            if specialization_filter != "All" and specialization_filter in track_map
            else specs
        )

        for track_key, track_data in tracks_to_search.items():
            track_label = track_key.replace("_", " ").title()
            score = 0

            # Search subcategories (Interactive Computing)
            if "subcategories" in track_data:
                for sub in track_data["subcategories"]:
                    sub_score = 0
                    for course in sub.get("courses", []):
                        text = f"{course.get('course_id','')} {course.get('title','')}".lower()
                        for term in q.split():
                            if len(term) > 2 and term in text:
                                sub_score += 5
                    if sub_score > 0 or any(t in sub["name"].lower() for t in q.split() if len(t) > 2):
                        results.append({
                            "score": sub_score + 3,
                            "section": f"Specialization - {track_label} - {sub['name']}",
                            "content": {
                                "track": track_label,
                                "requirement_summary": track_data.get("requirement_summary", ""),
                                "subcategory": sub["name"],
                                "credit_hours_required": sub["credit_hours_required"],
                                "instruction": sub.get("instruction", ""),
                                "courses": sub["courses"],
                            },
                        })
                    score = max(score, sub_score)

            # Search required/elective courses (other tracks)
            for section_key in ["required_courses", "elective_courses", "highly_recommended_courses"]:
                section = track_data.get(section_key, {})
                courses = section if isinstance(section, list) else section.get("courses", [])
                section_score = 0
                for course in courses:
                    text = f"{course.get('course_id','')} {course.get('title','')}".lower()
                    for term in q.split():
                        if len(term) > 2 and term in text:
                            section_score += 5
                if section_score > 0:
                    results.append({
                        "score": section_score,
                        "section": f"Specialization - {track_label} - {section_key.replace('_', ' ').title()}",
                        "content": {
                            "track": track_label,
                            "section": section_key,
                            "total_credit_hours": track_data.get("total_credit_hours", ""),
                            "minimum_grade": track_data.get("minimum_grade", "B"),
                            "courses": courses,
                        },
                    })
                score = max(score, section_score)

            # Return full track summary if no specific course match
            if score == 0:
                results.append({
                    "score": 1,
                    "section": f"Specialization - {track_label}",
                    "content": {
                        "track": track_label,
                        "total_credit_hours": track_data.get("total_credit_hours", ""),
                        "minimum_grade": track_data.get("minimum_grade", "B"),
                        "requirement_summary": track_data.get("requirement_summary", ""),
                        "notes": track_data.get("notes", ""),
                    },
                })

        return sorted(results, key=lambda x: x["score"], reverse=True)[:5]

    def _search_electives(
        self, handbook: dict, query: str, specialization_filter: str
    ) -> list[dict]:
        q = query.lower()
        results = []
        electives = handbook.get("elective_courses", {})

        # Always include the credit hour rules
        credit_rules = electives.get("credit_hours_by_specialization", {})
        results.append({
            "score": 3,
            "section": "Elective Credit Hour Requirements",
            "content": {
                "notes": electives.get("notes", []),
                "credit_hours_by_specialization": credit_rules,
            },
        })

        # Search approved electives by department
        for dept, courses in electives.get("approved_electives_by_department", {}).items():
            dept_score = 0
            matching_courses = []
            for course in courses:
                text = f"{course.get('course_id','')} {course.get('title','')}".lower()
                course_score = 0
                for term in q.split():
                    if len(term) > 2 and term in text:
                        course_score += 5
                    if term in dept.replace("_", " "):
                        course_score += 3
                if course_score > 0:
                    matching_courses.append(course)
                    dept_score += course_score

            if dept_score > 0:
                results.append({
                    "score": dept_score,
                    "section": f"Electives - {dept.replace('_', ' ').title()}",
                    "content": {
                        "department": dept.replace("_", " ").title(),
                        "matching_courses": matching_courses,
                    },
                })

        return sorted(results, key=lambda x: x["score"], reverse=True)[:5]

    def _search_project(self, handbook: dict, query: str) -> list[dict]:
        q = query.lower()
        project = handbook.get("research_project", {})
        results = []

        # Always return overview
        results.append({
            "score": 3,
            "section": "Research Project Overview",
            "content": {
                "course_id": project.get("course_id", ""),
                "total_credit_hours": project.get("total_credit_hours", ""),
                "structure": project.get("structure", ""),
                "minimum_grade": project.get("minimum_grade", ""),
                "prerequisites": project.get("prerequisites", ""),
                "workload_estimate": project.get("workload_estimate", ""),
                "overview": project.get("overview", ""),
                "industry_projects": project.get("industry_projects", ""),
                "irb_note": project.get("irb_note", ""),
            },
        })

        # Schedule
        schedule_terms = ["deadline", "when", "proposal", "submit", "schedule", "timeline", "midpoint", "presentation"]
        if any(t in q for t in schedule_terms):
            results.append({
                "score": 5,
                "section": "Research Project Schedule",
                "content": {"schedule": project.get("schedule", [])},
            })

        # Advisor
        advisor_terms = ["advisor", "mentor", "faculty", "change", "find", "who"]
        if any(t in q for t in advisor_terms):
            results.append({
                "score": 5,
                "section": "Research Project Advisor Requirements",
                "content": project.get("advisor_requirements", {}),
            })

        # Deliverables
        deliverable_terms = ["deliverable", "report", "proposal", "presentation", "format", "length", "pages"]
        if any(t in q for t in deliverable_terms):
            results.append({
                "score": 5,
                "section": "Research Project Deliverables",
                "content": project.get("deliverables", {}),
            })

        return results

    # ------------------------------------------------------------------ #
    # Main search dispatcher
    # ------------------------------------------------------------------ #

    def _run_search(self, query: str, section_filter: str, specialization_filter: str) -> dict:
        handbook = self._load_handbook()
        intent = self._detect_intent(query)

        # Section filter overrides intent detection if explicitly set
        if section_filter != "All":
            section_map = {
                "Degree Requirements": "degree_requirements",
                "Fixed Core Courses": "fixed_core_courses",
                "Specializations": "specializations",
                "Elective Courses": "elective_courses",
                "Research Project": "research_project",
                "Academic Calendar": "academic_calendar",
                "FAQs": "faqs",
                "Contact": "contact",
                "Other Requirements": "other_requirements",
            }
            intent = section_map.get(section_filter, intent)

        # Dispatch to the right search method
        if intent == "faqs":
            results = self._search_faqs(handbook, query)
        elif intent == "academic_calendar":
            results = self._search_calendar(handbook, query)
        elif intent == "contact":
            results = self._search_contact(handbook, query)
        elif intent == "research_project":
            results = self._search_project(handbook, query)
        elif intent == "elective_courses":
            results = self._search_electives(handbook, query, specialization_filter)
        elif intent == "specializations":
            results = self._search_specializations(handbook, query, specialization_filter)
        elif intent == "fixed_core_courses":
            results = self._search_core_courses(handbook, query)
        elif intent == "degree_requirements":
            results = self._search_requirements(handbook, query)
        else:
            # Search all sections and merge
            results = (
                self._search_faqs(handbook, query)
                + self._search_requirements(handbook, query)
                + self._search_core_courses(handbook, query)
                + self._search_specializations(handbook, query, specialization_filter)
                + self._search_electives(handbook, query, specialization_filter)
                + self._search_project(handbook, query)
                + self._search_calendar(handbook, query)
                + self._search_contact(handbook, query)
            )
            results = sorted(results, key=lambda x: x["score"], reverse=True)[:6]

        return {
            "query": query,
            "intent_detected": intent,
            "section_filter": section_filter,
            "specialization_filter": specialization_filter,
            "count": len(results),
            "results": [{"section": r["section"], "content": r["content"]} for r in results],
        }

    # ------------------------------------------------------------------ #
    # Tool mode
    # ------------------------------------------------------------------ #

    def build_tool(self) -> StructuredTool:
        return StructuredTool.from_function(
            name="handbook_search",
            description=(
                "Search the MS-HCI Student Handbook at Georgia Tech. "
                "Use this for questions about degree requirements, GPA rules, "
                "specialization tracks, elective courses, the research project, "
                "academic calendar dates, deadlines, contact information, "
                "and program policies. Input should be a natural language question."
            ),
            func=self._run_as_tool,
        )

    def _run_as_tool(self, query: str) -> str:
        self.query = query
        output = self._run_search(
            query=query,
            section_filter=getattr(self, "section_filter", "All"),
            specialization_filter=getattr(self, "specialization_filter", "All"),
        )

        if output["count"] == 0:
            return "No relevant information found in the MS-HCI Handbook for that query."

        lines = [
            f"Handbook search results for: '{query}'",
            f"Intent detected: {output['intent_detected']}",
            "",
        ]
        for r in output["results"]:
            lines.append(f"[{r['section']}]")
            lines.append(json.dumps(r["content"], indent=2))
            lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------ #
    # Standard component output
    # ------------------------------------------------------------------ #

    def search_handbook(self) -> Data:
        output = self._run_search(
            query=str(self.query),
            section_filter=self.section_filter,
            specialization_filter=self.specialization_filter,
        )
        return Data(data=output)
