import logging
import re
import time
import requests
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler

# ------------------------------------------------------------------ #
# Configuration — replace these with your actual values
# ------------------------------------------------------------------ #

SLACK_BOT_TOKEN = "token"
SLACK_APP_TOKEN = "token"

# Using direct local URL — no ngrok timeout issues
LANGFLOW_URL = "URL"
LANGFLOW_API_KEY = "API Key"

# ------------------------------------------------------------------ #
# Logging
# ------------------------------------------------------------------ #

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ------------------------------------------------------------------ #
# Markdown → Slack mrkdwn converter
# ------------------------------------------------------------------ #

def convert_to_slack_markdown(text: str) -> str:
    lines = text.split("\n")
    converted = []
    for line in lines:
        line = re.sub(r"^###\s+(.*)", r"*\1*", line)
        line = re.sub(r"^##\s+(.*)", r"*\1*", line)
        line = re.sub(r"^#\s+(.*)", r"*\1*", line)
        line = re.sub(r"\*\*(.*?)\*\*", r"*\1*", line)
        line = re.sub(r"__(.*?)__", r"*\1*", line)
        line = re.sub(r"~~(.*?)~~", r"~\1~", line)
        line = re.sub(r"\[([^\]]+)\]\((https?://[^\)]+)\)", r"<\2|\1>", line)
        line = line.replace("**", "*")
        converted.append(line)
    return "\n".join(converted)

# ------------------------------------------------------------------ #
# Response chunking — Slack blocks have a 3000 char limit
# ------------------------------------------------------------------ #

def split_into_chunks(text: str, max_length: int = 2000) -> list:
    if len(text) <= max_length:
        return [text]

    chunks = []
    while len(text) > max_length:
        split_at = text.rfind("\n\n", 0, max_length)
        if split_at == -1:
            split_at = text.rfind("\n", 0, max_length)
        if split_at == -1:
            split_at = max_length
        chunks.append(text[:split_at].strip())
        text = text[split_at:].strip()

    if text:
        chunks.append(text)

    return chunks

# ------------------------------------------------------------------ #
# Slack App
# ------------------------------------------------------------------ #

app = App(token=SLACK_BOT_TOKEN)

# ------------------------------------------------------------------ #
# Langflow call with retry logic
# ------------------------------------------------------------------ #

def call_langflow(user_message: str, session_id: str, retries: int = 3) -> str:
    for attempt in range(retries):
        try:
            logger.info(f"Calling Langflow (attempt {attempt + 1} of {retries})")
            session = requests.Session()
            response = session.post(
                LANGFLOW_URL,
                json={
                    "input_value": user_message,
                    "input_type": "chat",
                    "output_type": "chat",
                    "session_id": session_id,
                    "stream": False,
                },
                headers={
                    "Authorization": f"Bearer {LANGFLOW_API_KEY}",
                    "Content-Type": "application/json",
                },
                timeout=(30, 240),
            )
            response.raise_for_status()
            result = response.json()
            text = result["outputs"][0]["outputs"][0]["results"]["message"]["text"]
            session.close()
            logger.info(f"Response length: {len(text)} characters")
            return text

        except requests.exceptions.Timeout:
            logger.error(f"Langflow request timed out (attempt {attempt + 1})")
            if attempt < retries - 1:
                time.sleep(2)
            else:
                return "Sorry, I'm taking too long to respond. Please try again."

        except (KeyError, IndexError) as e:
            logger.error(f"Error parsing Langflow response: {e}")
            return "Sorry, I received an unexpected response. Please try again."

        except requests.exceptions.RequestException as e:
            logger.error(f"Error calling Langflow (attempt {attempt + 1}): {type(e).__name__}: {e}")
            if attempt < retries - 1:
                logger.info("Retrying in 3 seconds...")
                time.sleep(3)
            else:
                return "Sorry, I could not get a response. Please try again."

    return "Sorry, I could not get a response. Please try again."

# ------------------------------------------------------------------ #
# Message handlers
# ------------------------------------------------------------------ #

def process_message(event: dict, say, client) -> None:
    """Shared logic for handling messages across channels and DMs."""
    user_message = event.get("text", "").strip()
    user_id = event.get("user", "")
    channel_id = event.get("channel", "")
    thread_ts = event.get("thread_ts") or event.get("ts", "")

    # Ignore empty messages and bot messages
    if not user_message or event.get("bot_id"):
        return

    # Strip any @mention of the bot from the message
    user_message = re.sub(r"<@[A-Z0-9]+>", "", user_message).strip()
    if not user_message:
        return

    # Build a unique session ID per user and thread
    session_id = f"slack-{user_id}"

    logger.info(f"Message from {user_id} in {channel_id}: {user_message}")

    # Post thinking placeholder
    thinking_response = client.chat_postMessage(
        channel=channel_id,
        text="🧠 Thinking...",

    )
    thinking_ts = thinking_response["ts"]

    # Call Langflow
    answer = call_langflow(user_message, session_id)

    # Delete the thinking placeholder and post the real response
    try:
        client.chat_delete(channel=channel_id, ts=thinking_ts)
    except Exception:
        pass

    slack_answer = convert_to_slack_markdown(answer)
    chunks = split_into_chunks(slack_answer, max_length=2000)
    for chunk in chunks:
        say(
            blocks=[{"type": "section", "text": {"type": "mrkdwn", "text": chunk}}],
            text=chunk,
    
        )


@app.event("message")
def handle_message(event: dict, say, client) -> None:
    """Handle messages in channels and private channels."""
    if event.get("bot_id") or event.get("subtype"):
        return
    process_message(event, say, client)


@app.event("app_mention")
def handle_mention(event: dict, say, client) -> None:
    """Handle @mentions of the bot in channels."""
    process_message(event, say, client)


# ------------------------------------------------------------------ #
# Start the bot
# ------------------------------------------------------------------ #

if __name__ == "__main__":
    logger.info("Starting Next Course bot...")
    handler = SocketModeHandler(app, SLACK_APP_TOKEN)
    handler.start()
